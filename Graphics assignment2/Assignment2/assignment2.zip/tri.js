var tri = {
  "transformations": [
    {
      "prob": 0.3401,
      "trans_y": 1.96,
      "trans_x": 0.0,
      "rotate_scaleyy": 0.5,
      "rotate_scaleyx": 0.0,
      "rotate_scalexy": 0.0,
      "rotate_scalexx": 0.5
    },
    {
      "prob": 0.33,
      "trans_y": -0.68,
      "trans_x": 1.82,
      "rotate_scaleyy": -0.25,
      "rotate_scaleyx": -0.43,
      "rotate_scalexy": 0.43,
      "rotate_scalexx": -0.25
    },
    {
      "prob": 0.33,
      "trans_y": -0.88,
      "trans_x": -1.42,
      "rotate_scaleyy": -0.25,
      "rotate_scaleyx": 0.43,
      "rotate_scalexy": -0.43,
      "rotate_scalexx": -0.25
    }
  ],
  "name": "tri.ifs"
}